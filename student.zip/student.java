
public class ogrenci {

		public String name;
		public int ogrno;
		public String lastname;
		

public void Student()
{
	this.name = name;
	this.lastname = lastname;
	this.ogrno =  ogrno;
}
public String getName(){return name;}
public int getOgrno(){return ogrno;}
public String getLastName(){return lastname;}
public void setName(String name){this.name=name;}
public void setLastName(String lastname){this.lastname=lastname;}
public void setOgrno(int ogrno){this.ogrno=ogrno;}

}