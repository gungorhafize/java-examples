

import java.util.Scanner;
import java.util.*;

public class Ana {

	
	
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		ogrenci[] student = new ogrenci[5];
		Menu();
	}
	public static void Menu()
	{
		Scanner s =new Scanner(System.in);
		ogrenci[] student = new ogrenci[5];
		for(int i=0; i< student.length;i++)
		{
			student[i] = new ogrenci();
			}

		
		student[0].name  = "hafize";
		student[0].lastname = "gungor";

		student[0].ogrno =13;
		student[1].name = "hafize";
		student[1].lastname ="gungor";
		student[1].ogrno=12;
		int secenek;
		while(true){
		System.out.println("\nArama(1),Ekleme(2),Silme(3),Listeleme(4),��k��(5)");
		secenek= s.nextInt();
		
		
		switch(secenek)
		{
		case 1: System.out.println("\nArama kriteri se�iniz.�sim(1),Soyisim(2),Numara(3).");
		int i1 =0;
		while(i1<student.length-1){
		if(student[i1].ogrno>student[i1+1].ogrno)
		{
			
			ogrenci temp;
			temp=student[i1+1];
			student[i1+1]=student[i1];
			student[i1]=temp;
			
		}
		i1++;
		}
			int aramaicisecenek = s.nextInt();
			if(aramaicisecenek==1)
			{
				int i=0;
				System.out.println("\n�smi giriniz");
			String arama ;
			arama=s.next();
				
				for(i=0;i<student.length;i++)
				{
					if(arama.equals(student[i].name))
					{
						System.out.println("\n"+student[i].name+
								" "+student[i].lastname+" "+student[i].ogrno+" "+(i+1)+".");
				
					}
					else 
					{
						System.out.println("\n Bulunamad�.");
						break;
					}
				}
			}
				
				
			else if(aramaicisecenek==2)
			{
				int i=0;
				System.out.println("\nSoyismi giriniz");
			String arama =s.next();
				
				for(i=0;i<student.length;i++)
				{
					
				}if(arama.equals(student[i].lastname)){System.out.println("\n"+
							student[i].name+" "+student[i].lastname+" "+student[i].ogrno+" "+(i+1)+".");
				break;
				}else System.out.println("\n Bulunamad�.");
				break;
			}
			else if(aramaicisecenek==3)
			{
				int i=0;
				System.out.println("\nNumara giriniz");
			int arama=s.nextInt();
				
				for(i=0;i<student.length;i++)
				{
					
				}if(arama==student[i].ogrno){System.out.println("\n"+
							student[i].name+" "+student[i].lastname+" "+student[i].ogrno+" "+(i+1)+".");
				break;
				}else System.out.println("\n Bulunamad�.");
				break;
			}
			else System.out.println("\nHatal� giri� yapt�n�z.");
			break;
			case 2:
				for(int i=0;student.length>i;i++)
				{
					int numarakontrol;
					if(student[i].ogrno==0){
				System.out.println("\n��renci numaras�:");
				numarakontrol=s.nextInt();
				int j;
				for(j=0;j<student.length&&student[j].ogrno!=numarakontrol;j++)
				{
				}
				if(j!=student.length)
				{
				System.out.println("\n Kay�tlarda bu numarada ��renci var.");
				break;
				}else student[i].ogrno=numarakontrol;
		
				System.out.println("\n��renci ismi:");
				student[i].name=s.next();
				System.out.println("\n��renci Soyismi:");
				student[i].lastname=s.next();
				System.out.println("Devam etmek istiyor musunuz?(e/h)");
				String eh1=s.next();
				if(eh1.equals("h")){break;}
				
				}
					
			}
				int i11 =0;
				while(i11<student.length-1){
				if(student[i11].ogrno>student[i11+1].ogrno)
				{
					
					ogrenci temp;
					temp=student[i11+1];
					student[i11+1]=student[i11];
					student[i11]=temp;
					
				}
				i11++;
				}
				break;
			case 3: System.out.println("\n��renci numaras� giriniz:");
			int silinecek;
			int a;
			silinecek = s.nextInt();
			for(a=0;student[a].ogrno!=silinecek&&student.length>a;a++)
			{}
			System.out.println("\n�lgili kayd� silmek istedi�inize emin misiniz? (e/h)");
			String eh;
			eh=s.next();
			if(eh.equals("e")){
			student[a].ogrno=0;student[a].name=null;student[a].lastname=null;
			System.out.println("\n Silindi.");}
			else if(eh.equals("h"))
				break;
			else System.out.println("\nGe�ersiz giri�.");
			int i111 =0;
			while(i111<student.length-1){
			if(student[i111].ogrno>student[i111+1].ogrno)
			{
				
				ogrenci temp;
				temp=student[i111+1];
				student[i111+1]=student[i111];
				student[i111]=temp;
				
			}
			i111++;
			}
			break;
			case 4: System.out.println("\n��renci Listesi:");
			int i1111 =0;
			while(i1111<student.length-1){
			if(student[i1111].ogrno>student[i1111+1].ogrno)
			{
				
				ogrenci temp;
				temp=student[i1111+1];
				student[i1111+1]=student[i1111];
				student[i1111]=temp;
				
			}
			i1111++;
			}
				for(int i11111=0;i11111<student.length;i11111++)
				{
					if(student[i11111].ogrno!=0)
					System.out.println("\n"+student[i11111].name+" "+student[i11111].lastname+" "
				+student[i11111].ogrno);
					
				}
				break;
			case 5: System.exit(0);
			
			}
		}
	}
}